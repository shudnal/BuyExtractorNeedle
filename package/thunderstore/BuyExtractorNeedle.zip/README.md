# Buy Dvergr Extractor Needle

Buyable crate with dvergr extractor needle with customizable recipe. Press "Use" hotkey and buy its contents without fighting.

## Installation (manual)
Copy BuyExtractorNeedle.dll to your BepInEx\Plugins\ folder

## Configurating
The best way to handle configs is [Configuration Manager](https://thunderstore.io/c/valheim/p/shudnal/ConfigurationManager/).

Or [Official BepInEx Configuration Manager](https://valheim.thunderstore.io/package/Azumatt/Official_BepInEx_ConfigurationManager/).

## Mirrors
[Nexus](https://www.nexusmods.com/valheim/mods/2850)